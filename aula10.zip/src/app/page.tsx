"use client"
import React, { useState } from 'react';

import GlobalStyle from './styles/globals'
import Menu from './components/Menu';
import { ThemeProvider } from 'styled-components';
import { Container } from './style';

import light from './styles/light';
import dark from './styles/dark';

export default function Home() {
  const [theme, setTheme] = useState(light);

  return (
    <>
      <ThemeProvider theme={ theme }>
        <Container>
              <GlobalStyle />
              <Menu onChange={ checked => { setTheme(checked ? dark : light) } } />
              <h1>Home</h1>
        </Container>
      </ThemeProvider>
    </>
  );
}
