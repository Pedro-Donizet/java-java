import { useRouter } from "next/router";
import { useEffect, useState } from "react";


const incluirProduto = () =>{
    const router = useRouter();
    const[produtos,setProdutos] = useState({
        titulo : "",
        preco: "",
        quantidade : ""
    });
    const[loading,setLoading] = useState(true);
    const[error,setError] = useState("");

    const { id } = router.query;

    useEffect(()=>{
        if(id && id !== 'novo'){
            fetch(`http://localhost:8080/appRWD/rest/produto/${id}`)
            .then((resp) =>{
                if(!resp){
                    throw new Error("Erro ao buscar produto")
                }
                return resp.json();
            })
            .then((data)=>{
                setProdutos(data);
                setLoading(false);
            })
            .catch((error)=>{
                setError("Erro ao buscar produto");
                setLoading(false);
            });
        }
        else{
            setLoading(false)
        }
    },[id])

    const handleChange = (e) =>{
        setProdutos({...produtos,[e.target.name]:e.target.value})
    }

    const handleSubmit = (e) =>{
        e.preventDefault();

        const method = id && id !== "novo" ? "PUT" :  "POST";
        const url = id && id !== "novo" ? `http://localhost:8080/appRWD/rest/produto/${id}` : "http://localhost:8080/appRWD/rest/produto"

        fetch(url,{
            method,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(produtos)
        })
        .then(()=>{
            router.push("/")
        })
        .catch((error)=>{
            console.error("Erro ao salvar o produto: ", error);
        })
    }
    if(loading){
        return(
            <p>Carregando</p>
        )
    }

    return(
        <>
           <h1>{ id && id === 'novo' ? "Novo Produto" : "Editar Produto"}</h1>
           <form onSubmit={handleSubmit}>
            <label>Produto: </label>
            <input type="text" name="titulo" id="titulo" value={produtos.titulo} onChange={handleChange}/>
            <br/>
            <label>Quantidade: </label>
            <input type="text" name="quantidade" id="quantidade" value={produtos.quantidade} onChange={handleChange}/>
            <br/>
            <label>Preço: </label>
            <input type="number" name="preco" id="preco" step="0.01" value={produtos.preco} onChange={handleChange}/>
            <br/>
            <button type="submit">{ id && id === 'novo' ? "Inserir Produto" : "Salvar Produto"}</button>
           </form>
        </>
    )
}
export default incluirProduto;