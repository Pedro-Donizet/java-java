package aula17_ArrayList.exemplo5;

public class ListaTest {
	public static void main(String[] args) {
		
		Agenda agenda = new Agenda();
		
		//Adicionar contatos automaticamente
		for(int i = 1; i <= 5; i++) {
			Contato contato = new Contato("Nome " + i, "Telefone " + i, "Endereço " + i);
			agenda.adicionar(contato);
		}
		
		//Listagem inicial
		System.out.println(">> Primeira Listagem");
		agenda.listar();
		System.out.println("------------------------");
		
		//Atualizar
		System.out.println(">> Atualizar o primeiro contato");
		agenda.atualizar(0, new Contato("Claudio", "123", "FIAP"));
		System.out.println("------------------------");
		
		//Segunda Listagem
		System.out.println(">> Segunda Listagem");
		agenda.listar();
		System.out.println("------------------------");
		
		//Remover o primeiro contato
		System.out.println(">> Remover o primeiro contato");
		agenda.remover(0);
		System.out.println("------------------------");
		
		//Terceira  Listagem
		System.out.println(">> Terceira Listagem");
		agenda.listar();
		System.out.println("------------------------");
		
		//Pesquisar nome
		System.out.println(">> Pesquisar nome");
		System.out.println(agenda.pesquisarNome("Nome 2"));
		System.out.println(agenda.pesquisarNome("Claudio"));
		System.out.println("------------------------");

	}
}
