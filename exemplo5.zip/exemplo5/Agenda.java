package aula17_ArrayList.exemplo5;

import java.util.ArrayList;
import java.util.List;

public class Agenda {
	
	//declaração da lista
	private List<Contato> contatos;
	
	
	public Agenda() {
		this.contatos = new ArrayList<Contato>();
	}
	
	public void adicionar(Contato contato) {
		contatos.add(contato);
	}
	
	public void atualizar(int indice, Contato contato) {
		if(indice >=0 && indice < contatos.size()) {
			contatos.set(indice, contato);
		}
	}
	
	public void listar() {
		for (Contato contato : contatos) {
			//contato.toString(); //ou
			
			System.out.println(
					"Nome: " + contato.getNome() + "\n" +
					"Telefone: " + contato.getTelefone() + "\n" +
					"Endereço: " + contato.getEndereco() + "\n"		
			);
		}
	}
	
	public List<Contato> pesquisarNome(String nome){
		
		List<Contato> resultado = new ArrayList<>();
		
		for (Contato contato : contatos) {
			if(contato.getNome().equalsIgnoreCase(nome)) {
				resultado.add(contato);
			}
		}
		return resultado;
	}
	
	public void remover(int indice) {
		if(indice >=0 && indice < contatos.size()) {
			contatos.remove(indice);
		}
	}
}