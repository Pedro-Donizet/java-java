import { useState } from "react";
import { useRouter } from "next/router";

const LoginPage : React.FC = () =>{
    
    const router = useRouter();
    const [ username, setUsername ] = useState("")
    const [ password, setPassword ] = useState("");
    const [ error, setError] = useState("");

    const handleLogin = () =>{
        if(username === 'admin' && password === 'admin'){
            
            localStorage.setItem('isLoggedIn','true')
            router.push('/dashboard')
        }
        else{
            setError("Usuário e/ou senha incorretos!")
        }
    }

    return (
        <>
        <form>
            <label>Usuário: 
                <input type="text" value={ username } placeholder="Username" onChange={(e) => setUsername(e.target.value)} />
            </label>
            <br />
            <label>Senha:
                <input type="password" value={ password } placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
            </label>
            <br />
                { error && <span>{ error }</span> }
            <br />
            <button type="button" onClick={ handleLogin }>Login</button>
        </form>
        </>
    )
}

export default LoginPage;