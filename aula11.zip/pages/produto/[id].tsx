
const InserirProduto = () => {
    return(
        <>
            <h1>Inserir / Editar Produto</h1>
        </>
    )
}

export default InserirProduto; 