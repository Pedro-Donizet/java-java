import Link from "next/link";
import { useEffect, useState } from "react";


const ProdutosPage = () =>{

    const [produtos, setProdutos] = useState([]);

    useEffect(() =>{
        const fetchProdutos = async () =>{
            try{
                const res = await fetch('/api/produtos.json')
                const dados = await res.json();
                setProdutos(dados);
            } catch (error){
                console.error("Erro ao buscar os produtos", error)
            }
        };
        fetchProdutos()
    },[])

    return(
        <>
            <h1>Listagem de Produtos</h1>
            <ul>        
                {
                    produtos.map(produto => (
                        <li key={ produto.id }>
                           <Link href={`/produto/${produto.id}`}> 
                                { produto.nome }
                            </Link>
                        </li>
                    ))
                }
            </ul>
        </>
    )
}
export default ProdutosPage;