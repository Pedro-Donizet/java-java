import Image from "next/image";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";


const ProdutoPage = () => {

    const router = useRouter()
    const {id} = router.query;

    const [produto, setProduto] = useState(null);

    useEffect(() => {
        const fetchProduto = async () =>{
            try{
                const res = await fetch('/api/produtos.json');
                const dados = await res.json();
                const procuraProduto = dados.find((produto:{id:number}) =>produto.id === parseInt(id as string))
                setProduto(procuraProduto)
            } catch(error){
                console.error("Erro ao buscar o produto: ", error);
            }
        };
        fetchProduto();
    },[id]);

    if(!produto){
        return(
            <div>Produto não encontrado</div>
        )
    }

    return(
        <>
        <h1>{ produto.nome }</h1>
        <p>Preço: R$ { produto.preco.toFixed(2) } </p>
        <p>{ produto.id }</p>       
        {
            produto.imagem &&  produto.imagem.trim() !== "" ?(
        
                <Image src={ produto.imagem } alt="Bart" width={100} height={100} /> 
            ) : (null)
        }
        </> 
    )
}
export default ProdutoPage;